const codeInput = document.getElementById("code-input");
const explainBtn = document.getElementById("explain-btn");
const charCount = document.getElementById("char-count");
const resultsSection = document.getElementById("results");
const errorBox = document.getElementById("error-box");

const explanationEl = document.getElementById("result-explanation");
const issuesEl = document.getElementById("result-issues");
const suggestionsEl = document.getElementById("result-suggestions");

const MAX_LEN = 8000;

codeInput.addEventListener("input", () => {
  charCount.textContent = `${codeInput.value.length} / ${MAX_LEN}`;
});

function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove("hidden");
}

function clearError() {
  errorBox.textContent = "";
  errorBox.classList.add("hidden");
}

function renderList(el, items) {
  el.innerHTML = "";
  if (!items || items.length === 0) {
    const li = document.createElement("li");
    li.textContent = "None noted.";
    el.appendChild(li);
    return;
  }
  items.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    el.appendChild(li);
  });
}

async function explainCode() {
  const code = codeInput.value.trim();
  clearError();

  if (!code) {
    showError("Please paste some code first.");
    return;
  }

  explainBtn.disabled = true;
  explainBtn.textContent = "Analyzing...";
  resultsSection.classList.add("hidden");

  try {
    const resp = await fetch("/api/explain", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code }),
    });

    const data = await resp.json();

    if (!resp.ok) {
      showError(data.error || "Something went wrong. Please try again.");
      return;
    }

    if (data.warning) {
      showError(data.warning);
    }

    explanationEl.textContent = data.explanation || "No explanation returned.";
    renderList(issuesEl, data.issues);
    renderList(suggestionsEl, data.suggestions);
    resultsSection.classList.remove("hidden");
  } catch (err) {
    showError("Could not reach the server. Is the Flask app running?");
  } finally {
    explainBtn.disabled = false;
    explainBtn.textContent = "Explain my code";
  }
}

explainBtn.addEventListener("click", explainCode);

// Allow Ctrl/Cmd + Enter to submit from within the textarea
codeInput.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
    explainCode();
  }
});
