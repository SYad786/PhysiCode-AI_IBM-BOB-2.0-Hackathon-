# IBM Bob 2.0 Session Evidence

The hackathon submission requires proof that IBM Bob 2.0 was used during
development. Put your screenshots in this folder.

## What to capture

Take a screenshot any time Bob 2.0 meaningfully helps you, for example:

- [ ] Scaffolding the initial Flask project structure
- [ ] Writing or debugging `ai_client.py` (the watsonx.ai integration)
- [ ] Fixing a bug in the frontend JS (`static/script.js`)
- [ ] Refactoring or cleaning up any file
- [ ] Writing or improving the prompt in `prompts.py`
- [ ] Any back-and-forth where Bob explained something about the codebase
      to you (this is a great one to highlight, since it mirrors exactly
      what PhysiCode AI itself does for its users)

## Naming convention

Save each screenshot as:

```
bob_sessions/
├── 01_project_scaffold.png
├── 02_watsonx_integration_debug.png
├── 03_frontend_fix.png
└── ...
```

## Tip

Add one line under each image in this README describing what Bob helped
with — judges skim these fast, so a short caption goes a long way:

```
### 01_project_scaffold.png
Bob 2.0 helped scaffold the initial Flask app structure and requirements.txt.
```
