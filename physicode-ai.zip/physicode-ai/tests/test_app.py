"""
Basic smoke tests. These run entirely in DEMO MODE (no watsonx credentials
needed) so they work in any environment, including CI.

Run with:
    pytest
"""

import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pytest
from app import app


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


def test_index_loads(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert b"PhysiCode" in resp.data


def test_health_endpoint(client):
    resp = client.get("/api/health")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "ok"
    assert "provider_configured" in data


def test_explain_requires_code(client):
    resp = client.post("/api/explain", json={"code": ""})
    assert resp.status_code == 400
    assert "error" in resp.get_json()


def test_explain_demo_mode(client):
    sample = "for i in range(10):\n    x = i * 2\n"
    resp = client.post("/api/explain", json={"code": sample})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["mode"] == "demo"
    assert "explanation" in data
    assert isinstance(data["issues"], list)
    assert isinstance(data["suggestions"], list)


def test_explain_rejects_oversized_input(client):
    huge_code = "x = 1\n" * 5000
    resp = client.post("/api/explain", json={"code": huge_code})
    assert resp.status_code == 400
