"""
Prompt templates used to instruct the AI model (IBM watsonx.ai Granite, or any
other provider you plug in) to explain scientific/research code the way a
physics or STEM student needs it explained.

Keeping the prompt in its own file makes it easy to iterate on wording
without touching the client or server logic.
"""

SYSTEM_INSTRUCTIONS = """You are explaining code to a physics/STEM graduate \
student who understands mathematics and the underlying scientific concepts \
well, but has limited formal programming training.

For the code provided, respond with STRICT JSON only (no markdown fences, \
no commentary outside the JSON object), using exactly this shape:

{
  "explanation": "A section-by-section walkthrough in plain, non-jargon \
language. Explicitly connect each part to the physical or mathematical \
operation it performs (e.g. numerical integration method, discretization \
scheme, statistical fitting approach).",
  "issues": [
    "Each issue as one short sentence. Cover numerical instability risks, \
incorrect or inconsistent units, off-by-one errors, or logic that could \
silently produce wrong results without crashing. If you find no issues, \
return an empty list."
  ],
  "suggestions": [
    "One or two concrete, prioritized improvements. Prefer clarity and \
correctness over stylistic preference."
  ]
}

Return ONLY the JSON object. Do not wrap it in ```json fences.
"""


def build_prompt(code: str) -> str:
    """Builds the full prompt sent to the model for a given code snippet."""
    return (
        f"{SYSTEM_INSTRUCTIONS}\n\n"
        f"CODE TO ANALYZE:\n"
        f"```\n{code}\n```\n"
    )
