"""
PhysiCode AI -- Flask backend.

A minimal web app that explains research/scientific code (simulations,
numerical solvers, data-fitting scripts) in plain language, tuned for
physics/STEM students who code for research but aren't CS majors.

Run locally:
    pip install -r requirements.txt
    cp .env.example .env      # then fill in your watsonx.ai credentials
    python app.py
"""

import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv

import ai_client

load_dotenv()

app = Flask(__name__)

MAX_CODE_LENGTH = 8000  # characters; keeps requests small and predictable


@app.route("/")
def index():
    return render_template("index.html", provider_configured=ai_client.is_configured())


@app.route("/api/explain", methods=["POST"])
def api_explain():
    data = request.get_json(silent=True) or {}
    code = (data.get("code") or "").strip()

    if not code:
        return jsonify({"error": "Please paste some code first."}), 400

    if len(code) > MAX_CODE_LENGTH:
        return jsonify({
            "error": f"That's a lot of code! Please paste under "
                     f"{MAX_CODE_LENGTH} characters at a time."
        }), 400

    result = ai_client.explain_code(code)

    if result.get("mode") == "error":
        return jsonify({"error": result.get("error", "Something went wrong.")}), 400

    return jsonify(result)


@app.route("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "provider_configured": ai_client.is_configured(),
    })


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "true").lower() == "true"
    app.run(host="0.0.0.0", port=port, debug=debug)
