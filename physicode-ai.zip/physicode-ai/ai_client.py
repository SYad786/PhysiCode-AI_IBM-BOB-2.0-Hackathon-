"""
AI client for PhysiCode AI.

Talks to IBM watsonx.ai's Foundation Models REST API to run code explanation.
If no watsonx credentials are configured (e.g. you're still setting things
up, or demoing offline), it automatically falls back to a rule-based DEMO
MODE so the app is always responsive -- never a blank error screen during
a live demo.

Environment variables (see .env.example):
    WATSONX_API_KEY      IBM Cloud API key
    WATSONX_PROJECT_ID   watsonx.ai project ID
    WATSONX_URL          Region endpoint, e.g. https://us-south.ml.cloud.ibm.com
    WATSONX_MODEL_ID     Model to use, e.g. ibm/granite-3-8b-instruct
"""

import os
import json
import time
import re
import requests

IAM_TOKEN_URL = "https://iam.cloud.ibm.com/identity/token"
API_VERSION = "2023-05-29"

# Simple in-memory token cache so we don't re-auth on every request.
_token_cache = {"access_token": None, "expires_at": 0}


def _get_config():
    return {
        "api_key": os.environ.get("WATSONX_API_KEY", "").strip(),
        "project_id": os.environ.get("WATSONX_PROJECT_ID", "").strip(),
        "url": os.environ.get("WATSONX_URL", "https://us-south.ml.cloud.ibm.com").strip(),
        "model_id": os.environ.get("WATSONX_MODEL_ID", "ibm/granite-3-8b-instruct").strip(),
    }


def is_configured() -> bool:
    cfg = _get_config()
    return bool(cfg["api_key"] and cfg["project_id"])


def _get_iam_token(api_key: str) -> str:
    now = time.time()
    if _token_cache["access_token"] and _token_cache["expires_at"] > now + 30:
        return _token_cache["access_token"]

    resp = requests.post(
        IAM_TOKEN_URL,
        data={
            "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
            "apikey": api_key,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=20,
    )
    resp.raise_for_status()
    data = resp.json()
    _token_cache["access_token"] = data["access_token"]
    _token_cache["expires_at"] = now + data.get("expires_in", 3600)
    return _token_cache["access_token"]


def _extract_json(text: str) -> dict:
    """Best-effort extraction of a JSON object from model output, in case
    the model wraps it in prose or code fences despite instructions."""
    text = text.strip()
    # Strip ```json ... ``` fences if present
    fence_match = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.DOTALL)
    if fence_match:
        text = fence_match.group(1)
    else:
        # Fall back to grabbing the first {...} block
        brace_match = re.search(r"\{.*\}", text, re.DOTALL)
        if brace_match:
            text = brace_match.group(0)

    return json.loads(text)


def _call_watsonx(prompt: str) -> dict:
    cfg = _get_config()
    token = _get_iam_token(cfg["api_key"])

    url = f"{cfg['url']}/ml/v1/text/generation?version={API_VERSION}"
    body = {
        "model_id": cfg["model_id"],
        "input": prompt,
        "project_id": cfg["project_id"],
        "parameters": {
            "decoding_method": "greedy",
            "max_new_tokens": 900,
            "min_new_tokens": 0,
            "repetition_penalty": 1.0,
        },
    }
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    resp = requests.post(url, headers=headers, json=body, timeout=60)
    resp.raise_for_status()
    data = resp.json()

    generated_text = data["results"][0]["generated_text"]

    try:
        parsed = _extract_json(generated_text)
    except (json.JSONDecodeError, ValueError):
        # Model didn't return clean JSON -- degrade gracefully instead of
        # crashing the request.
        parsed = {
            "explanation": generated_text.strip(),
            "issues": [],
            "suggestions": [
                "The model's response could not be parsed as structured "
                "JSON, so it is shown as plain text above."
            ],
        }

    parsed.setdefault("explanation", "")
    parsed.setdefault("issues", [])
    parsed.setdefault("suggestions", [])
    return parsed


def _demo_mode_response(code: str) -> dict:
    """Rule-based offline fallback. Not a real analysis -- just keeps the
    UI fully functional (e.g. for local dev without credentials, or if the
    live API call fails during a demo)."""
    line_count = len(code.strip().splitlines()) or 1
    has_loop = bool(re.search(r"\bfor\b|\bwhile\b", code))
    has_numpy = "numpy" in code or "np." in code
    has_float_compare = bool(re.search(r"==\s*0\.0|0\.0\s*==", code))

    issues = []
    if has_float_compare:
        issues.append(
            "Direct equality comparison against a float (e.g. `== 0.0`) can "
            "silently fail due to floating-point precision -- use a small "
            "tolerance (e.g. abs(x) < 1e-9) instead."
        )
    if has_loop and not has_numpy:
        issues.append(
            "This code uses explicit loops for what looks like numerical "
            "work -- for large inputs this can be slow and may hide "
            "vectorization bugs that NumPy would catch."
        )
    if not issues:
        issues.append(
            "No obvious issues detected in demo mode. Connect a real "
            "provider (see README) for a full model-based review."
        )

    return {
        "explanation": (
            f"[DEMO MODE -- no AI provider configured]\n\n"
            f"This snippet has {line_count} line(s). In demo mode, "
            f"PhysiCode AI gives a lightweight, rule-based summary instead "
            f"of a full model-generated explanation. Connect IBM watsonx.ai "
            f"(see README.md) to get real, context-aware explanations tied "
            f"to the physics/math your code implements."
        ),
        "issues": issues,
        "suggestions": [
            "Set WATSONX_API_KEY and WATSONX_PROJECT_ID in your .env file "
            "to enable real AI-powered analysis.",
        ],
    }


def explain_code(code: str) -> dict:
    """Main entry point used by the Flask app.

    Returns a dict with keys: explanation (str), issues (list[str]),
    suggestions (list[str]), and mode ("watsonx" or "demo").
    """
    if not code or not code.strip():
        return {
            "explanation": "",
            "issues": [],
            "suggestions": [],
            "mode": "error",
            "error": "No code was provided.",
        }

    if not is_configured():
        result = _demo_mode_response(code)
        result["mode"] = "demo"
        return result

    from prompts import build_prompt  # local import keeps module import light

    try:
        result = _call_watsonx(build_prompt(code))
        result["mode"] = "watsonx"
        return result
    except requests.exceptions.RequestException as exc:
        # Network/auth failure during a live demo -- degrade gracefully
        # rather than showing the user a stack trace.
        result = _demo_mode_response(code)
        result["mode"] = "demo"
        result["warning"] = f"Live AI provider call failed ({exc}); showing demo mode."
        return result
